package SimpleCalculator;

import lt.techin.BasePage;
import lt.techin.HomePage;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
public class SimpleCalculator_test extends BaseTest{

@Test
    void testCalculator () {

    HomePage homePage = new HomePage(driver);

    homePage.enterInputNumberFirst("3");
    homePage.selectMathSign();
    homePage.enterInputNumberTwo("2");
    homePage.clickButtonSubmit();

    assertEquals("1", homePage.getAnswer());
    }

    @Test
    void testCalculatorError() {
        HomePage homePage = new HomePage(driver);

        homePage.enterInputNumberFirst("as");
        homePage.selectMathSign();
        homePage.enterInputNumberTwo("2");
        homePage.clickButtonSubmit();

        assertEquals("ERR", homePage.getAnswer());

    }

    @Test
    void testCalculatorWithMinusSign() {
        HomePage homePage = new HomePage(driver);

        homePage.enterInputNumberFirst("6000");
        homePage.selectMathSign();
        homePage.enterInputNumberTwo("1999");
        homePage.clickButtonSubmit();

        assertEquals(homePage.getAnswerWithMinus(6000, 1999), homePage.getAnswer());

    }
}
